/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.ui.grillas;

import demodao.objetos.Producto;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Hugo Chanampe
 */
public class GrillaProducto2 extends AbstractTableModel{
    
    private ArrayList<Producto> productos = new ArrayList<>();

    @Override
    public int getRowCount() {
        return productos.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
                Producto p = productos.get(rowIndex);
                
                switch(columnIndex){
                    case 0: return p.getId();
                    case 1: return p.getDenominacion();
                    case 2: return p.getCategoria().getDescripcion();
                    case 3: return p.getPrecioCosto();
                    case 4: return p.getPrecioVenta();
                    case 5: return p.getStock();
                    default: return "";

                }
    
    }

    @Override
    public String getColumnName(int column) {
        
        switch(column){
            case 0: return "ID";
            case 1: return "DENOMINACION";
            case 2: return "CATEGORIA";
            case 3: return "PRECIO COSTO";
            case 4: return "PRECIO VENTA";
            case 5: return "STOCK";
            default: return "";
        }
        
    }

    public GrillaProducto2(ArrayList<Producto> lp) {
        this.productos = lp;
    }
    
    
    public Producto getProducto(int row){
    
        return this.productos.get(row);
    
    }
    
    public void setDatos(ArrayList<Producto> listadoProducto){
    
        this.productos = listadoProducto;
    }
    
    public ArrayList<Producto> getDatos(){
    
        return this.productos;
    }
    
    
    
    
}
