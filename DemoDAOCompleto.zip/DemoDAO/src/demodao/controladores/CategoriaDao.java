/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.controladores;

import demodao.objetos.Categoria;
import java.util.ArrayList;

/**
 *
 * @author Hugo Chanampe
 */
public interface CategoriaDao {
    
    public ArrayList<Categoria> listar();
    public void insertarCategoria(Categoria c);
    public void modificarCategoria(Categoria c);
    public Categoria obtenerCategoria(Integer id);
    public void eliminarCategoria(Categoria c);
    
    
}
