/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.controladores;
import demodao.objetos.Producto;
import java.util.ArrayList;



/**
 *
 * @author Hugo Chanampe
 */
public interface ProductoDao {
    
   public ArrayList<Producto> listar();
   public Producto getProducto(Integer id);
   public void insertProducto(Producto p);
   public void updateProducto(Producto p);
   public void borrarProducto(Producto p);
           
           
    
}
