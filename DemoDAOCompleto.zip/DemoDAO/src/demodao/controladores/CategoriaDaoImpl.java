/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.controladores;

import demodao.dominio.ConnectionFactory;
import demodao.objetos.Categoria;
import demodao.objetos.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Hugo Chanampe
 */
public class CategoriaDaoImpl implements CategoriaDao{

    private Connection connection;
    
    private Statement stmt;
    
    private PreparedStatement ps;
    
    private ResultSet rs;
    
    private String sql;
    
    
    @Override
    public ArrayList<Categoria> listar() {
    
     connection = ConnectionFactory.getConnection();
        try{
            
            this.stmt = connection.createStatement();
            this.sql = "SELECT * FROM categorias";
            this.rs   = stmt.executeQuery(sql);
            
            ArrayList<Categoria> categorias = new ArrayList();
            
            while(rs.next()){
                
                Categoria categoria = new Categoria();
                
                categoria.setDenominacion(rs.getString("denominacion"));
                categoria.setDescripcion(rs.getString("descripcion"));
                categoria.setId(rs.getInt("id"));
                
                        //System.out.println(cliente);
                
                
                categorias.add(categoria);
                
            }
            //System.out.println(cont);
            return categorias;
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        return null;
    
    }
    
   

    @Override
    public void insertarCategoria(Categoria c) {
        
         connection = ConnectionFactory.getConnection();
         String sql = "INSERT INTO categorias (denominacion,descripcion) VALUES (?,?)";
        
        try {
            ps = connection.prepareStatement(sql);
            
            ps.setString(1, c.getDenominacion());
            ps.setString(2, c.getDescripcion());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "La Categoria ingresada es " + c); 

        } catch (SQLException ex) {
            Logger.getLogger(CategoriaDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    @Override
    public void modificarCategoria(Categoria c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Categoria obtenerCategoria(Integer id) {
        Categoria c = new Categoria();
    
        this.sql = "SELECT * FROM categorias WHERE id =?";
        
        connection = ConnectionFactory.getConnection();
        
        try {
            this.ps = connection.prepareStatement(sql);
            this.ps.setInt(1, id);
            this.rs  = ps.executeQuery();
            while(this.rs.next()){
            c.setDenominacion(rs.getString("denominacion"));
            c.setDescripcion(rs.getString("descripcion"));
            c.setId(rs.getInt("id"));
            }
            return c;
        } catch (SQLException ex) {
            Logger.getLogger(CategoriaDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        return null;
            

    }

    @Override
    public void eliminarCategoria(Categoria c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
