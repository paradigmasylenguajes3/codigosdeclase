/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimerprograma;

/**
 *
 * @author Hugo Chanampe
 */
public class Partido {
    
    private Equipo local;
    
    private Equipo visitante;
    
    
    private Balon balon;
    
    
}
