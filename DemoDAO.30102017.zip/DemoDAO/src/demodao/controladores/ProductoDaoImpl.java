/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.controladores;

import demodao.dominio.ConnectionFactory;
import demodao.objetos.Categoria;
import demodao.objetos.Producto;
import demodao.objetos.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Hugo Chanampe
 */
public class ProductoDaoImpl implements ProductoDao{
    
    private Statement stmt;
    private String sql;
    private ResultSet rs;
    private Connection connection;
    private PreparedStatement ps;

    @Override
    public ArrayList<Producto> listar() {
        connection = ConnectionFactory.getConnection();
        
        try{
            
            this.stmt = connection.createStatement();
            this.sql = "SELECT   productos.descripcion,productos.precio_costo,productos.precio_venta, productos.cantidad,productos.categoria_id,categorias.descripcion as categoria, productos.id FROM" +
                        " categorias,  productos WHERE productos.categoria_id = categorias.id";
            this.rs   = stmt.executeQuery(sql);
            
            ArrayList<Producto> productos=new ArrayList<>();
            
            while(rs.next()){
                
                Producto producto = extraerProductosDesdeRS(rs);
                //System.out.println(producto);
                productos.add(producto);
                
            }
            //System.out.println(cont);
            return productos;
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        return null;

        
    }

    @Override
    public Producto getProducto(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insertProducto(Producto p) {
        
        this.connection = ConnectionFactory.getConnection();
        this.sql = "INSERT INTO productos (descripcion,categoria_id,precio_costo,precio_venta,cantidad) VALUES (?,?,?,?,?)";
        
        try {
            ps = connection.prepareStatement(sql);
            
            ps.setString(1, p.getDenominacion());
            ps.setInt(2, p.getCategoria().getId());
            ps.setDouble(3, p.getPrecioCosto());
            ps.setDouble(4, p.getPrecioVenta());
            ps.setDouble(5, p.getStock());
            
            ps.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, cliente);
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }

    @Override
    public void updateProducto(Producto p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void borrarProducto(Producto p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private Producto extraerProductosDesdeRS (ResultSet rs) throws SQLException {

                Producto producto = new Producto();
                
                Categoria c = new Categoria();
                         
                c.setDenominacion(rs.getString("categoria"));
                
                c.setId(rs.getInt("categoria_id"));

                producto.setId( rs.getInt("id") );

                producto.setDenominacion(rs.getString("descripcion") );

                producto.setCategoria(c);

                producto.setPrecioCosto(rs.getDouble("precio_costo"));

                producto.setPrecioVenta(rs.getDouble("precio_venta"));

                producto.setStock(rs.getDouble("cantidad"));
    
                return producto;
    
}

   
    
}
