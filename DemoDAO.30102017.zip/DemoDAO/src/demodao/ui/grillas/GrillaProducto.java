/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.ui.grillas;

import demodao.objetos.Producto;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Hugo Chanampe
 */
public class GrillaProducto extends AbstractTableModel{
    
    private ArrayList<Producto> productos = new ArrayList<>();

    @Override
    public int getRowCount() {
        return productos.size();
    }

    @Override
    public int getColumnCount() {
        return 6; 
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
            
            Producto producto = productos.get(rowIndex);
            
            if(columnIndex ==0)
                return producto.getId();
            if(columnIndex ==1)
                return producto.getDenominacion();
            if(columnIndex==2)
                return producto.getCategoria();
            if(columnIndex==3)
                return producto.getPrecioCosto();
            if(columnIndex==4)
                return producto.getPrecioVenta();
            if(columnIndex==5)
                return producto.getStock();
                        
            return null;
    }
    
    public ArrayList<Producto> getDatos(){
            
       return productos;
    }

    @Override
    public String getColumnName(int column) {
    
        switch(column){
            case 0:     return "ID";
            case 1:     return "DENOMINACION";
            case 2:     return "CATEGORIA";
            case 3:     return "PRECIO COSTO";
            case 4:     return "PRECIO VENTA";
            case 5:     return "STOCK";
            default: return "";
                }
        
    }
       
    public void setDatos(ArrayList<Producto> lproductos){
    
        this.productos = lproductos;
    
    }
    
    public void agregarProducto(Producto p){
    
        productos.add(p);
    }
    
    public void quitarProductdo(Producto p){
    
        productos.remove(p);
    }
    
}
