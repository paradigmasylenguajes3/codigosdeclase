/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demodao.ui.grillas;

import demodao.objetos.Cliente;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Hugo Chanampe
 */
public class GrillaCliente extends AbstractTableModel{
    
    private ArrayList<Cliente> clientes;
    
    
    public ArrayList<Cliente> getDatos(){
    
        return clientes;
    
    }

    public void setDatos(ArrayList<Cliente> datos){
    
        clientes=datos;
    }
    
    @Override
    public int getRowCount() {
        return clientes.size();
    }

    @Override
    public int getColumnCount() {
        
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cliente cliente = clientes.get(rowIndex);
        
        
        switch(columnIndex){
        
            case 0:
                    return cliente.getId();
            case 1:
                    return cliente.getNombre();
            case 2: 
                    return cliente.getCuil();
            case 3: 
                    return cliente.getRazonSocial();
            default:
                    return null;
           
        }
       
        
    }

    @Override
     public String getColumnName(int column) {
        if (column == 0) {
            return "ID";
        }
        if (column == 1) {
            return "NOMBRE";
        }
        if (column == 2) {
            return "CUIL";
        }
        if (column == 3) {
            return "RAZON SOCIAL";
        }
        return ""; 
    }

    public GrillaCliente() {
        
        clientes= new ArrayList<>();
    
    }
    
    public void agregar(Cliente c){
    
        clientes.add(c);
        fireTableRowsInserted(clientes.size()-1,clientes.size()-1);
    
    }
    
    public void remover(Cliente c){
    
    clientes.remove(c);
            
    
    }
    
    
    
    
    
    
}
